# HashCode
HashCode 2K19

## Objectif
Top 1 mondial.

## Setup Git
git config --global credential.helper cache

git config --global credential.helper 'cache --timeout=3600'